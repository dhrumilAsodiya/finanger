package com.finanger.finanger_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinangerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
